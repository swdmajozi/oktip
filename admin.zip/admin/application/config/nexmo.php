<?php  (! defined('BASEPATH')) and exit('No direct script access allowed');
// please get the following api on Nexmo Dashboard.
$config['api_key'] = 'a8f4550c';
$config['api_secret'] = 'ADzdvKx5QqnmV49C';
/* End of file nexmo.php */
/* Location: ./application/config/nexmo.php */