<?php 

class Demo_blog_category_model extends MY_Model {
}