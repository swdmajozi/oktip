


<section  class="content" style="height:800px">
<!-- Small boxes (Stat box) -->

<!-- /.row -->



<table>
  
     <tr><td><h2>Welcome to Oktiq-Elearning System</h2></td></tr>
</table>
</div>


           
</section>
<!-- right col -->
</div>
<!-- /.row (main row) -->

   
                <!-- /.row -->

<style>
.timer  {
  text-align: center;
  font-size: 60px;
  margin-top: 0px;
}
</style>


<script type="text/javascript"> 
// Ajax post


function checkifexist(){


 var amount=$('#amount').val();
  var seller=$('#seller').val();
//alert(seller);

if(seller == '0' && amount==""){

  alert("Please select bucks first and amount");

}else{
     var  url = "<?php echo base_url();?>";
     var amount = '400';
 
   $.post(url+'dashboard/checkifexist', {amount:amount},function(result) { 

//alert(result);
        if(result !=0){       
              
         var  url = "<?php echo base_url();?>";

    alert("Sorry, One PH Allowed At A Time");
   

      
         }else { 
    



    var amount=$('#amount').val();
  //  alert(amount);
    var period=$('#period').val();
   //  alert(period);
     var seller=$('#seller').val();
    //  alert(seller);



     if(seller != 0 && amount>= 200 && amount <= 5000){


jQuery.ajax({
type: "POST",
url: "<?php echo base_url(); ?>" + "/dashboard/savedonation",
dataType: 'json',
data: {amount:amount, period:period, seller:seller},
success: function(res) {

  //  alert(res);
if (res != 1)
{
    alert("Donation Added Successfully!!!");
    

var url = '/dashboard/paymentsoutstanding';
 window.open(url) 
 window.location.href = url ;
    

}else{

       alert("Failed Please  try again");
}



}
});

}else{

  alert("Min Amount R200 - Max Amount R5000");

}

      
         }

    })
}
}
</script>

<!-- Morris.js charts -->


<style type="text/css">
    
td{
    padding: 10px !important;
}

</style>